#include "targets/xml_target.h"

/** @var create and register an evaluator for XML targets. */
og::xml_target og::xml_target::_self;
