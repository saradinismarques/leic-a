#include "targets/postfix_target.h"

/** @var create and register an evaluator for ASM targets. */
og::postfix_target og::postfix_target::_self;
