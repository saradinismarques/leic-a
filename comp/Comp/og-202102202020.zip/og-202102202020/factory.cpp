#include "factory.h"

/**
 * This object is automatically registered by the constructor in the
 * superclass' language registry.
 */
og::factory og::factory::_self;
