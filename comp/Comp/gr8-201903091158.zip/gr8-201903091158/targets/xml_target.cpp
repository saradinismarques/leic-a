#include "targets/xml_target.h"

/** @var create and register an evaluator for XML targets. */
gr8::xml_target gr8::xml_target::_self;
