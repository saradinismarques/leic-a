#include "targets/postfix_target.h"

/** @var create and register an evaluator for ASM targets. */
gr8::postfix_target gr8::postfix_target::_self;
