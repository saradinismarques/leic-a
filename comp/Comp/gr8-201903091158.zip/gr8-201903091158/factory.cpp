#include "factory.h"

/**
 * This object is automatically registered by the constructor in the
 * superclass' language registry.
 */
gr8::factory gr8::factory::_self;
