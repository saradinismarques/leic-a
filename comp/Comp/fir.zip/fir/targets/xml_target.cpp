#include "targets/xml_target.h"

/** @var create and register an XML targets. */
fir::xml_target fir::xml_target::_self;
