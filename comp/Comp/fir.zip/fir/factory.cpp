#include "factory.h"

/**
 * This object is automatically registered by the constructor in the
 * superclass' language registry.
 */
fir::factory fir::factory::_self;
