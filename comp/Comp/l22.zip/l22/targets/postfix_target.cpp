#include "targets/postfix_target.h"

/**
 * Postfix for ix86.
 * @var create and register an evaluator for ASM targets.
 */
l22::postfix_target l22::postfix_target::_self;
