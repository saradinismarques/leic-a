#include "targets/xml_target.h"

/** @var create and register an XML targets. */
l22::xml_target l22::xml_target::_self;
