#include "factory.h"

/**
 * This object is automatically registered by the constructor in the
 * superclass' language registry.
 */
l22::factory l22::factory::_self;
