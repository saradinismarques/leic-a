Simple compiler (based on CDK).
